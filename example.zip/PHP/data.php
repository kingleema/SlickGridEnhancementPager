﻿<?php 
$pageIndex = intval($_POST['pageIndex']);
$pageSize = intval($_POST['pageSize']);
$offset = ($pageIndex - 1) * $pageSize;
$arr = array(
  array('Id'=>1, 'Name'=>'Tim'),
  array('Id'=>2, 'Name'=>'Mary'),
  array('Id'=>3, 'Name'=>'Tom'),
  array('Id'=>4, 'Name'=>'Tony'),
  array('Id'=>5, 'Name'=>'Alice'),
  array('Id'=>6, 'Name'=>'Alex'),
  array('Id'=>7, 'Name'=>'Clark'),
  array('Id'=>8, 'Name'=>'Coffey'),
  array('Id'=>9, 'Name'=>'Danny'),
  array('Id'=>10,'Name'=>'Fred'),
  array('Id'=>11,'Name'=>'Lorry'),
  array('Id'=>12,'Name'=>'Freeman'),
  array('Id'=>13,'Name'=>'Grace'),
  array('Id'=>14,'Name'=>'Geoffrey'),
  array('Id'=>15,'Name'=>'Katharine'),
  array('Id'=>16,'Name'=>'Jackson'),
  array('Id'=>17,'Name'=>'John'),
  array('Id'=>18,'Name'=>'Kelsen'),
  array('Id'=>19,'Name'=>'Locke'),
  array('Id'=>20,'Name'=>'Luke'),
  array('Id'=>21,'Name'=>'Mark'),
  array('Id'=>22,'Name'=>'Michael'),
  array('Id'=>23,'Name'=>'Philemon'),
  array('Id'=>24,'Name'=>'Barrie'),
  array('Id'=>25,'Name'=>'Gill'),
  array('Id'=>26,'Name'=>'Kingsley')
);
$v = array_slice($arr, $offset, $pageSize, false);
$result = array('Total'=>count($arr), 'Rows'=>json_encode($v)); 
header('Content-type: text/plain; charset=utf-8');
sleep(2);
echo json_encode($result);
?>