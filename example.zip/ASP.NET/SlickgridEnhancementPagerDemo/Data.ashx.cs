﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace SlickgridEnhancementPagerDemo
{
    /// <summary>
    /// Return the test data.
    /// </summary>
    public class Data : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Charset = "utf-8";
            int pageSize = Convert.ToInt32(context.Request["pageSize"] ?? "10");
            int pageIndex = Convert.ToInt32(context.Request["pageIndex"] ?? "1");
            List<Employee> list = new List<Employee>();
            list.AddRange(ContentProvider);
            if (context.Request["Id"] != null && context.Request["Name"] != null)
            {
                list.Add(new Employee { Id = context.Request["Id"], Name = context.Request["Name"] });
            }
            int offset = (pageIndex - 1) * pageSize;
            string rows = JsonConvert.SerializeObject(list.Skip(offset).Take(pageSize).ToList());
            int count = list.Count;
            string returnedValue = JsonConvert.SerializeObject(new ReturnedStruct { Total = count, Rows = rows });
            System.Threading.Thread.Sleep(2000);
            context.Response.Write(returnedValue);
            context.Response.Flush();
        }

        public class Employee
        {
            public string Id { get; set; }
            public string Name { get; set; }
        }

        public List<Employee> ContentProvider
        {
            get
            {
                List<Employee> samples = new List<Employee>();
                samples.Add(new Employee { Id = "1", Name = "Tim" });
                samples.Add(new Employee { Id = "2", Name = "Mary" });
                samples.Add(new Employee { Id = "3", Name = "Tom" });
                samples.Add(new Employee { Id = "4", Name = "Tony" });
                samples.Add(new Employee { Id = "5", Name = "Alice" });
                samples.Add(new Employee { Id = "6", Name = "Alex" });
                samples.Add(new Employee { Id = "7", Name = "Clark" });
                samples.Add(new Employee { Id = "8", Name = "Coffey" });
                samples.Add(new Employee { Id = "9", Name = "Danny" });
                samples.Add(new Employee { Id = "10", Name = "Fred" });
                samples.Add(new Employee { Id = "11", Name = "Lorry" });
                samples.Add(new Employee { Id = "12", Name = "Freeman" });
                samples.Add(new Employee { Id = "13", Name = "Grace" });
                samples.Add(new Employee { Id = "14", Name = "Geoffrey" });
                samples.Add(new Employee { Id = "15", Name = "Katharine" });
                samples.Add(new Employee { Id = "16", Name = "Jackson" });
                samples.Add(new Employee { Id = "17", Name = "John" });
                samples.Add(new Employee { Id = "18", Name = "Kelsen" });
                samples.Add(new Employee { Id = "19", Name = "Locke" });
                samples.Add(new Employee { Id = "20", Name = "Luke" });
                samples.Add(new Employee { Id = "21", Name = "Mark" });
                samples.Add(new Employee { Id = "22", Name = "Michael" });
                samples.Add(new Employee { Id = "23", Name = "Philemon" });
                samples.Add(new Employee { Id = "24", Name = "Barrie" });
                samples.Add(new Employee { Id = "25", Name = "Gill" });
                samples.Add(new Employee { Id = "26", Name = "Kingsley" });
                return samples;
            }
        }

        public class ReturnedStruct
        {
            public int Total { get; set; }
            public string Rows { get; set; }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}